﻿import Chat from "./Chat";
import "./App.css";

export default function App() {
  return <Chat />;
}