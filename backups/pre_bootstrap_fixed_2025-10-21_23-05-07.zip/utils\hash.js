﻿const crypto = require("crypto");
module.exports.sha256 = (bufOrStr) => {
  const hash = crypto.createHash("sha256");
  hash.update(bufOrStr);
  return hash.digest("hex");
};
module.exports.sleep = (ms)=> new Promise(r=>setTimeout(r,ms));
