﻿// D:\Alice\projects\chat-app\client\postcss.config.cjs
module.exports = {
  plugins: []
};